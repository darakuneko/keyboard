#pragma once
#include "gpk_rc.h"

enum id_device_get_value_t {
    id_device_get_value         = 0x01
};

enum id_device_operation_t {
    id_layer_move = 0x01,
    id_oled_write = 0x02
};
