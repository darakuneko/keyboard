# QMK version 0.14.32

# via json
download: [ld50themetaler's via json](https://github.com/ld50themetaler/etc/blob/4d5f54cb97ccfbf9e9ad6ad3909cc0ad852f1bfb/uzu42_via.json)
