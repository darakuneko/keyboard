# The default keymap for gpk60_46a
