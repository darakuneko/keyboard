#pragma once

#define VIAL_KEYBOARD_UID {0xB9, 0x58, 0xB6, 0xD1, 0xD2, 0x8F, 0x6A, 0x2A}
#define VIAL_UNLOCK_COMBO_ROWS {0, 0}
#define VIAL_UNLOCK_COMBO_COLS {0, 1}