#pragma once

#include "config_common.h"

/* USB Device descriptor parameter */
#define VENDOR_ID    0xFEED
#define PRODUCT_ID   0x1523
#define DEVICE_VER   0x0001
#define MANUFACTURER Daraku-Neko
#define PRODUCT      Yamada65 Pro
