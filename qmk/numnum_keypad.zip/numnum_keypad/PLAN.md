# NumNum Keypad Vial Keymap Implementation Plan

## Context

NumNum Keypadのvialキーマップに3つの機能を追加実装する:
1. **TM1637 2桁7セグメントディスプレイドライバ** — ライブラリなしで自力実装（`devices/`フォルダ）
2. **トグルスイッチ（Switch20, M-N11S1E）のDIPスイッチ化** — マトリクス[4,3]にあるがトグルスイッチのため別途状態管理
3. **RS16211 1P8T ロータリースイッチ** — GP1-GP8をQMK DIPスイッチ機能で実装

DIPスイッチのキーは仮で`KC_0`/`KC_1`を割り当て（後で変更予定）。

## Implementation

### 1. TM1637ドライバ作成（新規ファイル）

**`numnum_keypad/devices/tm1637.h`** — ヘッダファイル
- ピン定義（CLK=GP10, DIO=GP9）
- API: `tm1637_init()`, `tm1637_display_number()`, `tm1637_set_brightness()`, `tm1637_clear()`
- 7セグメントエンコーディングテーブル（0-9, ブランク, ダッシュ等）

**`numnum_keypad/devices/tm1637.c`** — ドライバ実装
- ビットバング通信プロトコル（I2C類似）:
  - Start: CLK HIGH中にDIO HIGH→LOW
  - バイト送信: LSBファースト、8ビット+ACK
  - Stop: CLK HIGH中にDIO LOW→HIGH
- TM1637コマンド:
  - `0x40`: データ書き込み（アドレス自動インクリメント）
  - `0xC0`: アドレス設定（表示位置0）
  - `0x88-0x8F`: 表示ON + 明るさ制御
- 2桁表示: GRID1=右桁, GRID2=左桁（回路図より）
- 用途: 現在のレイヤー番号を表示

### 2. DIPスイッチ設定

**`numnum_keypad/config.h`** に追加:
```c
// ロータリースイッチ (RS16211 1P8T) — GP1-GP8
#define DIP_SWITCH_PINS { GP1, GP2, GP3, GP4, GP5, GP6, GP7, GP8 }

// トグルスイッチ (M-N11S1E) — マトリクス[4,3]
#define DIP_SWITCH_MATRIX_GRID { {4, 3} }
```

QMKのDIPスイッチ機能を使用:
- GPIO DIPスイッチ（インデックス0-7）: ロータリースイッチ8ポジション
- マトリクスDIPスイッチ（インデックス8）: トグルスイッチ
- 合計9個のDIPスイッチとして認識

### 3. キーマップ更新

**`numnum_keypad/keymaps/vial/keymap.c`** の変更点:
- `[4,3]`はDIPスイッチで処理するため全レイヤーで`KC_NO`に設定
- `dip_switch_update_user()` コールバック追加（仮キー: KC_0/KC_1）
- `layer_state_set_user()` 追加: レイヤーに応じたRGB色変更 + TM1637表示更新
  - Layer 0: Cyan (H=128)
  - Layer 1: Purple (H=191)
  - Layer 2: Green (H=85)
  - Layer 3: Yellow (H=43)
- `keyboard_post_init_user()` でTM1637初期化

### 4. ビルド設定

**`numnum_keypad/rules.mk`** （新規作成 — キーボードレベル）:
```makefile
SRC += devices/tm1637.c
DIP_SWITCH_ENABLE = yes
```

**`numnum_keypad/keymaps/vial/rules.mk`** に追加:
```makefile
DIP_SWITCH_MAP_ENABLE = yes
```

## Files Summary

| ファイル | 操作 | 内容 |
|---|---|---|
| `numnum_keypad/devices/tm1637.h` | 新規作成 | TM1637ドライバヘッダ |
| `numnum_keypad/devices/tm1637.c` | 新規作成 | TM1637ドライバ実装 |
| `numnum_keypad/rules.mk` | 新規作成 | SRC, DIP_SWITCH_ENABLE |
| `numnum_keypad/config.h` | 編集 | DIPスイッチピン定義追加 |
| `numnum_keypad/keymaps/vial/keymap.c` | 編集 | DIPスイッチ・TM1637・レイヤーRGB統合 |
| `numnum_keypad/keymaps/vial/rules.mk` | 編集 | DIP_SWITCH_MAP_ENABLE追加 |

## Verification

QMKファームウェアツリー内で `make numnum_keypad:vial` でコンパイルが通ることを確認。
（ただし本リポジトリ単体ではQMKツリーがないためビルド検証は不可）
