# The via keymap for lain

## Leds setting
1: CAPS LOCK   
2-3: Layor indicator

## Via user keycode
USER(0) : toggle leds enable
