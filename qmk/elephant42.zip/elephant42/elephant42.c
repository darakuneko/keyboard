#include "elephant42.h"
