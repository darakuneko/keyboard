# elephant42-firmware

elephant42 (aka 🐘42) s firmware.

1. Set up QMK and copy this directory under `keyboards/` as `elephant42`.
1. `qmk flash -kb elephant42 -km default`
    * or `qmk flash -kb elephant42 -km via`

### Why don't you publish it under GPLv2&v3, the same as QMK?

Because I want to drink beer with your treat. 🍺🍺🍺

Don't worry! Beerware seems to be GPL compatible.

https://fedoraproject.org/wiki/Licensing/Beerware

(If there is a problem, please point it out. I don't want to fight over trivial things.😉)
