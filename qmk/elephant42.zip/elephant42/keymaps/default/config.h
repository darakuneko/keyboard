#pragma once

// place overrides here
#ifdef OLED_ENABLE
#define OLED_FONT_H "keymaps/default/glcdfont.c"
#endif
