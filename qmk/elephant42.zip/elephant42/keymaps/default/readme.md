# The default keymap for elephant42
